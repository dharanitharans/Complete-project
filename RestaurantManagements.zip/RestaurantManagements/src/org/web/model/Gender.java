package org.web.model;

public enum Gender {
	MALE, FEMALE,OTHERS;

}
