package org.web.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.DinningTable;
import org.web.util.HBUtil;

/**
 * Servlet implementation class TableUpdate
 */
@WebServlet("/tableupdate")
public class TableUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static DinningTable table1=null;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TableUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tbl = request.getParameter("table");
		Session session1 = HBUtil.get().openSession();
		session1.beginTransaction();
		DinningTable table = session1.get(DinningTable.class, String.valueOf(tbl.charAt(5)));
		table.setTableStatus("Occupied");
		table.setUsers(LoginService.userReturn());
		
		session1.update(table);
		session1.getTransaction().commit();
		session1.close();
		Session session2 = HBUtil.get().openSession();
		session2.beginTransaction();
		table1 = session2.get(DinningTable.class, String.valueOf(tbl.charAt(5)));
		session2.getTransaction().commit();
		session2.close();
		response.sendRedirect("view");
	}
	public  static DinningTable tableReturn() {
		return table1;
	}

}
