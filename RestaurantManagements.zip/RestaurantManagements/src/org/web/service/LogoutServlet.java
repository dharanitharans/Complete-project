package org.web.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.DinningTable;
import org.web.util.HBUtil;
import org.web.util.Utility;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LogoutServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Session session=HBUtil.get().openSession();
		session.beginTransaction();
		DinningTable table=TableUpdate.tableReturn();
		if(table!=null)
		{
		table.setTableStatus("Available");
		table.setUsers(null);
		session.update(table);
		}
		session.getTransaction().commit();
		session.close();
		
		String username = Utility.getCookieValue(request, "auth_user");
		String code = Utility.getCookieValue(request, "auth_key");
		LoginService.logout(response, username, code);
		try (PrintWriter out = response.getWriter()) {
			
			request.getRequestDispatcher("index.html").include(request, response);
		}
	}

}
