package org.web.service;

import java.io.IOException;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.Cart;
import org.web.model.Item;
//import org.web.model.OrderItem;
import org.web.model.Users;
//import org.web.serv.TableReturn;
import org.web.util.HBUtil;

/**
 * Servlet implementation class Order
 */
@WebServlet("/order")
public class Order extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		Users user=LoginService.userReturn();
		//List<Item> items = new LinkedList<Item>();
		Item itm=new Item();
		Cart itm1=null;
		Cart cart=new Cart();
		Query query;
		Query query1;
		String[] item = request.getParameterValues("checked");
		String[] quantity= request.getParameterValues("Quantity");
		int i;
		int quantity1=0;
		Session session=HBUtil.get().openSession();
		session.beginTransaction();
		for(String e: item){
			int a=Integer.parseInt(e);
			query = session.createQuery("from Item where itemId=:id");
			query.setParameter("id",a);
			query1 = session.createQuery("from Cart where itemId=:id and bill_status=:status");
			query1.setParameter("id",a);
			query1.setParameter("status","notpaid");
			itm=(Item) query.getSingleResult();
			
			try{
				itm1=(Cart) query1.getSingleResult();
			}
			catch (NoResultException nre){
				}
			for(i=0;i<quantity.length;i++)
			{
				if(quantity[i]!="" && quantity[i]!="0")
				{
					quantity1=Integer.parseInt(quantity[i]);
					itm.setItemQuantity(quantity1);
					Double b=Double.parseDouble(itm.getItemPrice());
					if(itm1 != null)
					{
						Session session2=HBUtil.get().openSession();
						Query query2=session2.createQuery("UPDATE Cart  SET item_quantity=:quantity,total_price=:price WHERE item_id=:id");
				    	query2.setParameter("id",itm1.getItemId());
				    	query2.setParameter("quantity",itm1.getQuantity()+quantity1);
				    	query2.setParameter("price",b*(itm1.getQuantity()+quantity1));					    	
				    	session2.beginTransaction();
				    	query2.executeUpdate();
						
				    	session2.getTransaction().commit();
				    	session2.close();
					}
					else
					{
					Session session1 = HBUtil.get().openSession();
					cart.setItemId(a);;
					cart.setQuantity(quantity1);
					cart.setStatus("notpaid");
					cart.setTotal_price(b*itm.getItemQuantity());
					cart.setUser(user);
					session1.save(cart);
					session1.beginTransaction();
					session1.getTransaction().commit();
					session1.close();
					}
					quantity[i]="0";
					break;
					
				}
			}
			
			
		}
		
		session.getTransaction().commit();
		session.close();
		response.sendRedirect("viewcart");
	}

}
