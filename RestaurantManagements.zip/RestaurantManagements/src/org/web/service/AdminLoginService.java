package org.web.service;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.web.model.Admin;
//import org.hibernate.SessionFactory;
import org.web.util.HBUtil;
import org.web.util.Utility;
public class AdminLoginService {
	static Admin usr=new Admin();
	public static String validate(String username, String password) {
		String code = null;
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		Admin admin = session.get(Admin.class, username);
		if (admin != null && admin.getPassword().equals(password)) {
			if (admin.getCode().isEmpty()) {
				code = Utility.generateKey(20);
				admin.setCode(code);
				session.update(admin);
				
				
			} else {
				code = "";
			}
		}
		session.getTransaction().commit();
		session.close();
		return code;
	}
		
	
	public static boolean logout(HttpServletResponse response, String username, String code) {
		boolean status = false;
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		Admin admin = session.get(Admin.class, username);
		if (admin != null && admin.getCode().equals(code)) {
			Cookie cookie = new Cookie("auth_admin", "");
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			cookie = new Cookie("auth_adminkey", "");
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			admin.setCode("");
			status = true;
			session.update(admin);
		}
		session.getTransaction().commit();
		session.close();
		return status;
	}

	public static boolean check(String username, String code) {
		boolean status = false;
		Session session = HBUtil.get().openSession();
		Admin admin = session.get(Admin.class, username);
		if (admin != null && admin.getCode().equals(code)) {
			status = true;
		}
		session.close();
		return status;
	}
	


}
