package org.web.service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.Address;
import org.web.model.Gender;
import org.web.model.Users;
import org.web.util.HBUtil;

/**
 * Servlet implementation class Profile
 */
@WebServlet("/profile")
public class Profile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Profile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		String gender = request.getParameter("gender");
		String date = request.getParameter("dob");
		String doorno = request.getParameter("doorno");
		String city = request.getParameter("city");
		String pincode = request.getParameter("pincode");
		Date date1 = null;
		Gender gen=Gender.valueOf(gender);
		try {
			date1 = formatter.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		Address address =new Address();
		address.setCity(city);
		address.setDoorNo(doorno);
		address.setPincode(pincode);
		Users user =LoginService.userReturn();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setGender(gen);
		user.setDateOfBirth(date1);
		user.setAddress(address);
		session.update(user);
		session.getTransaction().commit();
		session.close();
	}

}
