package org.web.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.web.model.Cart;
import org.web.model.DinningTable;
import org.web.model.Orders;
import org.web.model.Users;
import org.web.util.HBUtil;

/**
 * Servlet implementation class ProceedToPayment
 */
@WebServlet("/proceedtopayment")
public class ProceedToPayment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProceedToPayment() {
        super();
        // TODO Auto-generated constructor stub
    }
    private static double totalprice=0;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				Orders ordered_itm=new Orders();
				Session session = HBUtil.get().openSession();
				session.beginTransaction();
				double price=0;
				Query query = session.createQuery("from Cart where cart_username_fk=:name and bill_status=:status");
				query.setParameter("status","notpaid");
				query.setParameter("name",LoginService.userReturn());
				@SuppressWarnings("unchecked")
				List<Cart> cart_Items = (List<Cart>) query.getResultList();
				for(Cart e:cart_Items)
				{
					price=e.getTotal_price()+price;
					
				}
				ordered_itm.setTable(TableUpdate.tableReturn());
				ordered_itm.setCartItems(cart_Items);
				ordered_itm.setPrice(price);
				totalprice=price;
				ordered_itm.setUser(LoginService.userReturn());
				Users user =LoginService.userReturn();
				query = session.createQuery("update Users set credits=:credits where username=:username");
				query.setParameter("credits",user.getCredits()+((price*2)/100));
				System.out.println((user.getCredits()+((price*2)/100)));
				query.setParameter("username",LoginService.userReturn().getUserName());
				DinningTable table=TableUpdate.tableReturn();
				table.setTableStatus("Available");
				table.setUsers(null);
				
				session.save(ordered_itm);
				session.update(table);
				query.executeUpdate();
				session.getTransaction().commit();
				session.close();
				
				Session session1 = HBUtil.get().openSession();
				Query query1 = session1.createQuery("update Cart set bill_status=:status");
				query1.setParameter("status","paid");
				session1.beginTransaction();
				query1.executeUpdate();
				session1.getTransaction().commit();
				session1.close();
				request.getRequestDispatcher("paymentmode.html").include(request, response);
				
	}
public static double PriceReturn()
{
	return totalprice;
}

}
