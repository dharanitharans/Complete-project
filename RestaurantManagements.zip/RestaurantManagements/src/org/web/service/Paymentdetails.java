package org.web.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.Bank;
import org.web.model.CardDetails;
import org.web.util.HBUtil;

/**
 * Servlet implementation class Paymentdetails
 */
@WebServlet("/paymentdetails")
public class Paymentdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Paymentdetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String holdername = request.getParameter("holdername");
		String cardnumber = request.getParameter("cardnumber");
		String month = request.getParameter("month");
		String year = request.getParameter("year");
		Session session = HBUtil.get().openSession();
		double price=ProceedToPayment.PriceReturn();
		double balance=0;
		session.beginTransaction();
		Bank bank=session.get(Bank.class,Long.parseLong(cardnumber));
		if(bank.getAccountNo()==Long.parseLong(cardnumber) && bank.getCardHolderName().equals(holdername) && bank.getExpMonth()==Integer.parseInt(month) && bank.getExpYear()==Integer.parseInt(year))
		{
			if(bank.getAmount()>price)
			{
			CardDetails card =session.get(CardDetails.class,Long.parseLong(cardnumber));
			if(card!=null)
			{
			card=new CardDetails();
			card.setCardHolderName(holdername);
			card.setAccountNo(Long.parseLong(cardnumber));
			card.setExpMonth(Integer.parseInt(month));
			card.setExpYear(Integer.parseInt(year));
			card.setUser(LoginService.userReturn());
			session.save(card);
			System.out.println("payment successful");
			}
			}
			else
			System.out.println("Insufficient Balance");
			balance=bank.getAmount()-price;
			bank.setAmount(balance);
			session.update(bank);
		}
		
		session.getTransaction().commit();
		session.close();
		request.getRequestDispatcher("success.html").include(request, response);
		//doGet(request, response);
	}

}
