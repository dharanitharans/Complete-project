package org.web.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HBUtil {
	private static SessionFactory sessionFactory;

	/**
	 * This method returns sessionFactory as static service
	 * 
	 * @return SessionFactory Object
	 */
	public static SessionFactory get() {
		if (sessionFactory == null) {
			sessionFactory = new Configuration().configure().buildSessionFactory();
		}
		return sessionFactory;
	}
}
