package org.web.serv;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.Item;
import org.web.util.HBUtil;


/**
 * Servlet implementation class adddb
 */
@WebServlet("/additem")
public class adddb extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public adddb() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Session session = HBUtil.get().openSession();
		String name = request.getParameter("itemName");
		String price = request.getParameter("itemPrice");
		String type = request.getParameter("itemType");
		String category = request.getParameter("itemCategory");
		Item item=new Item();
		item.setItemName(name);
		item.setItemPrice(price);
		item.setItemType(type);
		item.setItemCategory(category);
		session.beginTransaction();
		session.save(item);
		session.getTransaction().commit();
		response.sendRedirect("manageitems");
	}



}
