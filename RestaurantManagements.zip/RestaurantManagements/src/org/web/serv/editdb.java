package org.web.serv;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.Item;
import org.web.util.HBUtil;

/**s
 * Servlet implementation class editdb
 */
@WebServlet("/edititem")
public class editdb extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public editdb() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String id = request.getParameter("itemid");
		String name = request.getParameter("itemName");
		String price = request.getParameter("itemPrice");
		String type = request.getParameter("itemType");
		String category = request.getParameter("itemCategory");
		try(PrintWriter out=response.getWriter())
		{
				Session session = HBUtil.get().openSession();
		    	Query query=session.createQuery("from Item WHERE item_id=:id");
		    	query.setParameter("id",Integer.parseInt(id));
		    	Item item=(Item) query.getSingleResult();
		    	item.setItemName(name);
		    	item.setItemPrice(price);
		    	item.setItemType(type);
		    	item.setItemCategory(category);
		    	session.beginTransaction();
		    	session.update(item);
		    	session.getTransaction().commit();
		    	session.close();
		    	response.sendRedirect("manageitems");
		 
	
			
		}
		}
	}


