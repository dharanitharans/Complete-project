package org.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.Users;
import org.web.util.HBUtil;

/**
 * Servlet implementation class UserNameValidate
 */
@WebServlet("/usernamevalidate")
public class UserNameValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserNameValidate() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int a=0;
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Users");
		List<Users> person = (List<Users>) query.getResultList();
		String username = request.getParameter("user");
		try (PrintWriter out = response.getWriter()) {
			response.setContentType("text/html");
			
			for (Users each : person) {
				if (username.equals(each.getUserName())) {
					
					a=1;
					out.println("<!DOCTYPE html><html><head><title>Username validate</title></head><body>");
					out.println("<h1 style=\"text-align:center;margin-top: 100px;\">Username Already Exist</h1>");
					out.println("</body></html>");
					request.getRequestDispatcher("signup.html").include(request, response);
					break;
				}

			}
			if(a==0)
			{
			out.println("<!DOCTYPE html><html><head><title>Username validate</title></head><body>");
			out.println("<h1 style=\"text-align:center;margin-top: 100px;\">Username Not Exists</h1>");
			out.println("</body></html>");
			request.getRequestDispatcher("signup.html").include(request, response);
			}
		}
		session.getTransaction().commit();
		session.close();
		
	}

}
