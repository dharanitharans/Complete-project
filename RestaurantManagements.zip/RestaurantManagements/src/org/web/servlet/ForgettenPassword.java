package org.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web.service.EmailServices;
import org.web.util.HBUtil;
import org.hibernate.Session;
import org.web.model.Users;

/**
 * Servlet implementation class ForgettenPassword
 */
@WebServlet("/forgettenpassword")
public class ForgettenPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgettenPassword() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String to=request.getParameter("email");
		String username=request.getParameter("username");
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Users where username=:username");
		query.setParameter("username",username);
		Users user=(Users) query.getSingleResult();
		session.getTransaction().commit();
		session.close();
		System.out.println("HI EMAIL SERVLET");
		PrintWriter out = response.getWriter();
		String subject="Your password is";
		String msg=user.getPassword();
		EmailServices.send(to, subject, msg);
		response.setContentType("text/html");
		out.println("<html>");
		out.println("<meta charset=ISO-8859-1>");
		out.println(
				"<link rel=\"stylesheet\" href=css/bootstrap.min.css> <link rel=\"stylesheet\" href=css/bootstrap.css>");
		out.println("<head>");
		out.println("<title>message has been sent successfully</title>");
		out.println("</head>");

		out.close();

		doGet(request, response);
	}

}
