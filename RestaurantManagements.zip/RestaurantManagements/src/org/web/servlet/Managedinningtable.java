package org.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.DinningTable;
import org.web.util.HBUtil;

/**
 * Servlet implementation class Managedinningtable
 */
@WebServlet("/managedinningtable")
public class Managedinningtable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Managedinningtable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try (PrintWriter out = response.getWriter()) {
			response.setContentType("text/html");
			Session session = HBUtil.get().openSession();
			session.beginTransaction();
			out.println("<html>");
			out.println("<meta charset=ISO-8859-1>");
			out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n"
					+ "  <link rel=\"stylesheet\" href=\"style/css/bootstrap.min.css\">\r\n"
					+ "  <script src=\"style/jquery/jquery.min.js\"></script>\r\n"
					+ "  <script src=\"style/js/bootstrap.min.js\"></script>\r\n"
					+ "");
			out.println("<link rel=\"stylesheet\" href=css/bootstrap.min.css> <link rel=\"stylesheet\" href=css/bootstrap.css>");
			out.println("<head>");
			out.println("<title>Insert title here</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<nav class=\"navbar navbar-inverse\">\r\n" + 
					"  <div class=\"container-fluid\">\r\n" + 
					"    <div class=\"navbar-header\">\r\n" + 
					"      <a class=\"navbar-brand\" href=\"#\">Restaurant Management</a>\r\n" + 
					"    </div>\r\n" + 
					"    <ul class=\"nav navbar-nav\">\r\n" + 
					"      <!--  <li class=\"active\"><a href=\"#\">Home</a></li>-->\r\n" + 
					"         </ul>\r\n" + 
					"    <ul class=\"nav navbar-nav navbar-right\">\r\n" + 
					"     <!--   <li><a href=\"#\"><span class=\"glyphicon glyphicon-user\"></span> Sign Up</a></li>-->\r\n" + 
					"      <!--  <li><a href=\"#\"><span class=\"glyphicon glyphicon-log-in\"></span> Login</a></li>-->\r\n" + 
					"      <li class=\"dropdown\"><a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">User</a>\r\n" + 
					"        <ul class=\"dropdown-menu\">\r\n" +  
					"          <li><a href=\"adminlogout\">Logout</a></li>\r\n" + 
					"          <!--  <li><a href=\"#\">Page 1-3</a></li>-->\r\n" + 
					"        </ul>\r\n" + 
					"      </li>\r\n" + 
					"      \r\n" + 
					"    </ul>\r\n" + 
					"  </div>\r\n" + 
					"</nav>\r\n" + 
					"");
			
			int page = 1;
			if (request.getParameter("page") != null)
				page = Integer.parseInt(request.getParameter("page"));
			Query query = session.createQuery("from DinningTable");
			@SuppressWarnings("unchecked")
			List<DinningTable> person = (List<DinningTable>) query.getResultList();
			int size = person.size();
			System.out.println(size);
			query = session.createQuery("from DinningTable");
			query.setFirstResult((page - 1) * 10);
			query.setMaxResults(page * 10);
			@SuppressWarnings("unchecked")
			List<DinningTable> table_all = (List<DinningTable>) query.getResultList();

			out.println("<div class=container><div class=container-fluid-center><div class=row>");
			out.println("<div class=col></div><div class=col>");

			out.println("<div class=col>");
			//out.println("<form action=\"logout\">");
			//out.println("<br><input type=submit value=logout class=btn btn-info style=\"margin-left=00px;\">");
			out.println("</form></div>");
			out.println("</div></div>");
			int k = ((size - 1) / 10) + 1;
			out.println("<nav aria-label=...>" + "<ul class=pagination pagination-lg>" + "<li class=page-item disabled>"
					+ "</li>");
			out.println("<ul class=pagination justify-content-center>");
			for (int i = 1; i <= k; i++) {
				out.println(
						"<li class=page-item active><a class=page-link href=managedinningtable?page=" + i + ">" + i + "</a></li>");

			}
			out.println(" </ul>");
			out.println("<li class=page-item>" + "</li>" + "</ul>" + "</nav>");
			out.println("</div></div>");
			out.println("</div></body>");
			out.println("</html>");
			out.println("<div class=row style=\"margin-top:50px; margin-left:150px;\">");
			//out.println("<form action=\"order\" method=get>");
			out.println("<table class=table>");
			out.println("<thead>");
			out.println("<tr>");
			out.println("<th scope=col>Number</th>");
			out.println("<th scope=col>Status</th>");
			out.println("<th scope=col>Username</th>");
			out.println("</tr>");
			out.println("</thead>");
			for (DinningTable each : table_all) {
				out.println("<tbody>");
				out.println("<tr>");
				out.println(
						"<th><input type=text name=Name value=" + each.getTableNumber() + "  style=border:none;></th>");
				out.println(
						"<th><input type=text name=Name value=" + each.getTableStatus() + "  style=border:none;></th>");
				try	{
				out.println(
						"<th><input type=text name=Name value=" + each.getUsers().getUserName() + "  style=border:none;></th>");
				}
				catch(Exception e)
				{
					out.println("<th><input type=text name=Name value=" + each.getUsers() + "  style=border:none;></th>");
				}
				
								//out.println("<th><input type=text name=Quantity placeholder=Quantitys style=border:none;><br></th>");
				out.println("</tr>");
				out.println("</tbody>");
			}
			out.println("</table>");
			//out.println("<input type=submit name=button value=Order class=btn btn-info>");

			//out.println("</form>");
			session.getTransaction().commit();
			session.close();
			}
		}

		//response.getWriter().append("Served at: ").append(request.getContextPath());
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
