package org.web.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.Admin;
import org.web.util.HBUtil;

/**
 * Servlet implementation class AdminValidate
 */
@WebServlet("/adminvalidate")
public class AdminValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminValidate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String username = request.getParameter("user");
		String password = request.getParameter("pass");
		//String password1 = request.getParameter("pass1");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");

		Admin admin = new Admin();
		admin.setName(username);
		admin.setPassword(password);
		admin.setEmail(email);
		admin.setMobilenumber(mobile);;
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		session.save(admin);
		session.getTransaction().commit();
		session.close();
		request.getRequestDispatcher("adminlogin.html").include(request, response);

	}

}
