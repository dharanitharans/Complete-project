package org.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.web.model.DinningTable;
import org.web.util.HBUtil;

/**
 * Servlet implementation class Dinningtable
 */
@WebServlet("/dinningtable")
public class Dinningtable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Dinningtable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try (PrintWriter out = response.getWriter()) {
			Session session = HBUtil.get().openSession();
			out.println("<html>");
			out.println("<meta charset=ISO-8859-1>");
			out.println(
					"<link rel=\"stylesheet\" href=css/bootstrap.min.css> <link rel=\"stylesheet\" href=css/bootstrap.css>");
			out.println("<head>");
			out.println("<style>\r\n" + 
					"body {\r\n" + 
					"	background-repeat: no-repeat;\r\n" + 
					"	background-size: 100% 100%;\r\n" + 
					"}\r\n" + 
					"</style>\r\n" + 
					"");
			out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n"
					+ "  <link rel=\"stylesheet\" href=\"style/css/bootstrap.min.css\">\r\n"
					+ "  <script src=\"style/jquery/jquery.min.js\"></script>\r\n"
					+ "  <script src=\"style/js/bootstrap.min.js\"></script>\r\n"
					+ "");
			
			out.println("<title>Table Selection</title>");
			out.println("</head>");
			out.println("<body background=\"s.jpg\">");
			out.println("<h1 class=\"text\"\r\n" + 
					"					style=\"text-align: center; font; margin-top: 100px;\">Avalible Tables\r\n</h1>\r\n" + 
					"				");
			//out.println("<h1>Available Tables</h1>");
			out.println("<nav class=\"navbar navbar-inverse\">\r\n" + "  <div class=\"container-fluid\">\r\n"
					+ "    <div class=\"navbar-header\">\r\n"
					+ "      <a class=\"navbar-brand\" href=\"#\">Restaurant Management</a>\r\n" + "    </div>\r\n"
					+ "    <ul class=\"nav navbar-nav\">\r\n"
					+ "     </ul>\r\n"
					+ "    <ul class=\"nav navbar-nav navbar-right\">\r\n" 
					+ "      <li class=\"dropdown\"><a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">User</a>\r\n"
					+ "        <ul class=\"dropdown-menu\">\r\n"
					+ "          <li><a href=\"profile.html\">Edit Profile</a></li>\r\n"
					+ "          <li><a href=\"logout\">Logout</a></li>\r\n"
					+ "          <!--  <li><a href=\"#\">Page 1-3</a></li>-->\r\n" + "        </ul>\r\n"
					+ "      </li>\r\n" + "      \r\n" + "    </ul>\r\n" + "  </div>\r\n" + "</nav>\r\n" + "");

			
			int page = 1;
			if (request.getParameter("page") != null)
				page = Integer.parseInt(request.getParameter("page"));
			Query query = session.createQuery("from DinningTable");
			@SuppressWarnings("unchecked")
			List<DinningTable> tableList = (List<DinningTable>) query.getResultList();
			out.println("<div class=\"content\">");
			out.println("<div class=\"container\">");
			for (DinningTable each : tableList) {
				if(each.getTableStatus().equals("Available"))
				{
				out.println("<form action=\"tableupdate\" method=post>");
		    	out.println("<input type=submit name=table value=table"+each.getTableNumber()+" class=\"btn btn-primary btn-lg btn-block style=\"border:none; text-align:center\">");
		    	
		    	//out.println("</div>");
				out.println("</form>");
				}
				
	}
			out.println("</div>");
	    	out.println("</div>");
			session.close();
		}

}
		/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		}
}
